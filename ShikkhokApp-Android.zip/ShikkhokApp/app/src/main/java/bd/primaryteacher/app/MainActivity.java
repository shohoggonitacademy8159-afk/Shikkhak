package bd.primaryteacher.app;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import android.print.PrintManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;

public class MainActivity extends Activity {

    private static final String ASSET_URL = "file:///android_asset/index.html";
    private static final String MARKER = "SHIKKHOK_APP";

    private WebView web;
    private SharedPreferences prefs;
    private File updFile;
    private JSONObject config;
    private boolean clearHistoryOnFinish = false;
    private WebView printView;
    private final ExecutorService io = Executors.newSingleThreadExecutor();
    private final AtomicBoolean busy = new AtomicBoolean(false);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(0xFF1E7F4F);

        prefs = getSharedPreferences("updates", MODE_PRIVATE);
        updFile = new File(new File(getFilesDir(), "www"), "index.html");
        config = readConfig();

        web = new WebView(this);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setTextZoom(100);
        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                if ("file".equals(uri.getScheme())) {
                    return false;
                }
                openExternal(uri);
                return true;
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                if (clearHistoryOnFinish) {
                    clearHistoryOnFinish = false;
                    view.clearHistory();
                }
            }
        });
        web.addJavascriptInterface(new Bridge(), "AppBridge");
        setContentView(web);
        loadApp();
    }

    /* ---------- which copy of the app to show ---------- */

    private int contentCode() {
        int c = prefs.getInt("contentCode", 0);
        return (c > BuildConfig.APP_CODE && updFile.exists()) ? c : BuildConfig.APP_CODE;
    }

    private String contentVersion() {
        if (contentCode() == BuildConfig.APP_CODE) {
            return BuildConfig.VERSION_NAME;
        }
        return prefs.getString("contentVersion", BuildConfig.VERSION_NAME);
    }

    private void loadApp() {
        if (contentCode() > BuildConfig.APP_CODE) {
            try {
                String html = new String(readAll(new FileInputStream(updFile)), StandardCharsets.UTF_8);
                if (html.contains(MARKER)) {
                    // Same base URL as the built-in copy, so saved data (localStorage) stays the same.
                    web.loadDataWithBaseURL(ASSET_URL, html, "text/html", "UTF-8", null);
                    return;
                }
            } catch (Exception ignored) {
            }
        }
        web.loadUrl(ASSET_URL);
    }

    /* ---------- update check ---------- */

    private JSONObject readConfig() {
        try {
            String txt = new String(readAll(getAssets().open("config.json")), StandardCharsets.UTF_8);
            JSONObject o = new JSONObject(txt);
            return o.has("updateBase") ? o : null;
        } catch (Exception e) {
            return null;
        }
    }

    private void doCheck(boolean manual) {
        if (config == null) {
            send(status("noconfig", manual));
            return;
        }
        send(status("checking", manual));
        try {
            String base = config.getString("updateBase");
            JSONObject v = new JSONObject(httpGet(base + "version.json?t=" + System.currentTimeMillis()));
            int code = v.getInt("code");
            int nativeCode = v.optInt("nativeCode", 0);
            String version = v.optString("version", "");
            String notes = v.optString("notes", "");

            boolean needApk = nativeCode > BuildConfig.NATIVE_CODE;
            boolean savedWeb = false;

            if (code > contentCode()) {
                String html = httpGet(base + "index.html?t=" + System.currentTimeMillis());
                if (html.length() < 10000 || !html.contains(MARKER)) {
                    throw new Exception("invalid update file");
                }
                File dir = updFile.getParentFile();
                if (dir != null && !dir.exists() && !dir.mkdirs()) {
                    throw new Exception("cannot create folder");
                }
                File tmp = new File(dir, "index.tmp");
                FileOutputStream out = new FileOutputStream(tmp);
                try {
                    out.write(html.getBytes(StandardCharsets.UTF_8));
                } finally {
                    out.close();
                }
                if (!tmp.renameTo(updFile)) {
                    throw new Exception("cannot save update");
                }
                prefs.edit().putInt("contentCode", code).putString("contentVersion", version).apply();
                savedWeb = true;
            }

            if (needApk) {
                // The new screens are saved too; the new APK is needed only for new phone features.
                JSONObject s = status("apk", manual);
                s.put("version", version);
                s.put("notes", notes);
                s.put("webSaved", savedWeb);
                s.put("url", "https://github.com/" + config.optString("repo", "")
                        + "/releases/latest/download/app-debug.apk");
                send(s);
                return;
            }
            if (savedWeb) {
                JSONObject s = status("web", manual);
                s.put("version", version);
                s.put("notes", notes);
                send(s);
                return;
            }

            send(status("uptodate", manual));
        } catch (Exception e) {
            send(status("error", manual));
        }
    }

    private JSONObject status(String state, boolean manual) {
        JSONObject o = new JSONObject();
        try {
            o.put("state", state);
            o.put("manual", manual);
        } catch (Exception ignored) {
        }
        return o;
    }

    private void send(JSONObject s) {
        final String js = "window.onUpdateStatus&&window.onUpdateStatus(" + JSONObject.quote(s.toString()) + ")";
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                web.evaluateJavascript(js, null);
            }
        });
    }

    private static String httpGet(String url) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        c.setConnectTimeout(15000);
        c.setReadTimeout(20000);
        c.setUseCaches(false);
        try {
            if (c.getResponseCode() != 200) {
                throw new Exception("HTTP " + c.getResponseCode());
            }
            return new String(readAll(c.getInputStream()), StandardCharsets.UTF_8);
        } finally {
            c.disconnect();
        }
    }

    private static byte[] readAll(InputStream in) throws Exception {
        try {
            ByteArrayOutputStream buf = new ByteArrayOutputStream();
            byte[] b = new byte[8192];
            int n;
            while ((n = in.read(b)) != -1) {
                buf.write(b, 0, n);
            }
            return buf.toByteArray();
        } finally {
            in.close();
        }
    }

    private void openExternal(Uri uri) {
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, uri));
        } catch (Exception ignored) {
        }
    }

    /* ---------- printing (certificates) ---------- */

    private void printHtml(String title, String html) {
        final String job = (title == null || title.trim().isEmpty()) ? "Certificate" : title.trim();
        final WebView pv = new WebView(this);
        pv.getSettings().setJavaScriptEnabled(false);
        pv.setWebViewClient(new WebViewClient() {
            private boolean done = false;

            @Override
            public void onPageFinished(WebView view, String url) {
                if (done) {
                    return;
                }
                done = true;
                try {
                    PrintManager pm = (PrintManager) getSystemService(PRINT_SERVICE);
                    PrintDocumentAdapter adapter = view.createPrintDocumentAdapter(job);
                    PrintAttributes attrs = new PrintAttributes.Builder()
                            .setMediaSize(PrintAttributes.MediaSize.ISO_A4)
                            .build();
                    pm.print(job, adapter, attrs);
                } catch (Exception ignored) {
                }
            }
        });
        printView = pv; // keep a reference until printing is done
        pv.loadDataWithBaseURL(ASSET_URL, html, "text/html", "UTF-8", null);
    }

    /* ---------- functions the page can call ---------- */

    private class Bridge {
        @JavascriptInterface
        public String getInfo() {
            JSONObject o = new JSONObject();
            try {
                o.put("apk", BuildConfig.VERSION_NAME);
                o.put("content", contentVersion());
                o.put("configured", config != null);
            } catch (Exception ignored) {
            }
            return o.toString();
        }

        @JavascriptInterface
        public void checkUpdate(final boolean manual) {
            if (!busy.compareAndSet(false, true)) {
                return;
            }
            io.execute(new Runnable() {
                @Override
                public void run() {
                    try {
                        doCheck(manual);
                    } finally {
                        busy.set(false);
                    }
                }
            });
        }

        @JavascriptInterface
        public void applyUpdate() {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    clearHistoryOnFinish = true;
                    loadApp();
                }
            });
        }

        @JavascriptInterface
        public void print(final String title, final String html) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    printHtml(title, html);
                }
            });
        }

        @JavascriptInterface
        public void openUrl(final String url) {
            if (url == null || !url.startsWith("https://github.com/")) {
                return;
            }
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    openExternal(Uri.parse(url));
                }
            });
        }
    }

    @Override
    @SuppressWarnings("deprecation")
    public void onBackPressed() {
        if (web.canGoBack()) {
            web.goBack();
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onDestroy() {
        io.shutdownNow();
        super.onDestroy();
    }
}

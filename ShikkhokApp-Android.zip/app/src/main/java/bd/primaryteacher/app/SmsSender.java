package bd.primaryteacher.app;

import android.Manifest;
import android.app.Activity;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.os.Build;
import android.telephony.SmsManager;
import android.telephony.SubscriptionInfo;
import android.telephony.SubscriptionManager;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Sends SMS from the phone's own SIM (uses the SIM's SMS pack).
 * One message at a time is requested by the page; long Bangla texts are split into parts,
 * and the result is reported once every part has a "sent" status from the radio.
 */
final class SmsSender {

    interface Listener {
        void onResult(String key, boolean ok, String code);
    }

    static final int PERM_REQUEST = 1006;
    private static final String ACTION = "bd.primaryteacher.app.SMS_SENT";

    private final Activity act;
    private final Listener listener;
    /** key -> {parts, partsDone, firstErrorCode or -1} */
    private final Map<String, int[]> pending = new HashMap<String, int[]>();
    private int reqSeq = 0;

    private final BroadcastReceiver receiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context c, Intent i) {
            partDone(i.getStringExtra("key"), getResultCode());
        }
    };

    SmsSender(Activity a, Listener l) {
        act = a;
        listener = l;
        IntentFilter f = new IntentFilter(ACTION);
        if (Build.VERSION.SDK_INT >= 33) {
            act.registerReceiver(receiver, f, Context.RECEIVER_NOT_EXPORTED);
        } else {
            act.registerReceiver(receiver, f);
        }
    }

    void release() {
        try {
            act.unregisterReceiver(receiver);
        } catch (Exception ignored) {
        }
    }

    boolean hasPermission() {
        return act.checkSelfPermission(Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED;
    }

    private boolean canReadSims() {
        return act.checkSelfPermission(Manifest.permission.READ_PHONE_STATE) == PackageManager.PERMISSION_GRANTED;
    }

    void requestPermission() {
        act.requestPermissions(new String[]{Manifest.permission.SEND_SMS, Manifest.permission.READ_PHONE_STATE}, PERM_REQUEST);
    }

    /** {perm, telephony, sims:[{id, label}]} */
    String status() {
        JSONObject o = new JSONObject();
        JSONArray sims = new JSONArray();
        try {
            o.put("perm", hasPermission());
            o.put("telephony", act.getPackageManager().hasSystemFeature(PackageManager.FEATURE_TELEPHONY));
            if (canReadSims()) {
                SubscriptionManager sm = (SubscriptionManager) act.getSystemService(Context.TELEPHONY_SUBSCRIPTION_SERVICE);
                List<SubscriptionInfo> list = sm == null ? null : sm.getActiveSubscriptionInfoList();
                if (list != null) {
                    for (SubscriptionInfo si : list) {
                        JSONObject s = new JSONObject();
                        CharSequence name = si.getCarrierName();
                        if (name == null || name.length() == 0) name = si.getDisplayName();
                        s.put("id", si.getSubscriptionId());
                        s.put("label", "সিম " + (si.getSimSlotIndex() + 1) + (name != null && name.length() > 0 ? " — " + name : ""));
                        sims.put(s);
                    }
                }
            }
            o.put("sims", sims);
        } catch (Exception ignored) {
        }
        return o.toString();
    }

    void send(String key, String phone, String text, int subId) {
        if (!hasPermission()) {
            listener.onResult(key, false, "perm");
            return;
        }
        try {
            SmsManager m = manager(subId);
            ArrayList<String> parts = m.divideMessage(text);
            int n = parts.size();
            if (n == 0) {
                listener.onResult(key, false, "3");
                return;
            }
            synchronized (pending) {
                pending.put(key, new int[]{n, 0, -1});
            }
            ArrayList<PendingIntent> sent = new ArrayList<PendingIntent>();
            for (int i = 0; i < n; i++) {
                Intent it = new Intent(ACTION).setPackage(act.getPackageName()).putExtra("key", key);
                sent.add(PendingIntent.getBroadcast(act, ++reqSeq, it, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT));
            }
            if (n == 1) {
                m.sendTextMessage(phone, null, text, sent.get(0), null);
            } else {
                m.sendMultipartTextMessage(phone, null, parts, sent, null);
            }
        } catch (SecurityException e) {
            forget(key);
            listener.onResult(key, false, "perm");
        } catch (Exception e) {
            forget(key);
            listener.onResult(key, false, subId >= 0 ? "nosim" : "1");
        }
    }

    @SuppressWarnings("deprecation")
    private SmsManager manager(int subId) {
        if (Build.VERSION.SDK_INT >= 31) {
            SmsManager m = act.getSystemService(SmsManager.class);
            return subId >= 0 ? m.createForSubscriptionId(subId) : m;
        }
        return subId >= 0 ? SmsManager.getSmsManagerForSubscriptionId(subId) : SmsManager.getDefault();
    }

    private void forget(String key) {
        synchronized (pending) {
            pending.remove(key);
        }
    }

    private void partDone(String key, int rc) {
        if (key == null) return;
        int[] st;
        boolean finished;
        synchronized (pending) {
            st = pending.get(key);
            if (st == null) return;
            st[1]++;
            if (rc != Activity.RESULT_OK && st[2] < 0) st[2] = rc;
            finished = st[1] >= st[0];
            if (finished) pending.remove(key);
        }
        if (finished) listener.onResult(key, st[2] < 0, String.valueOf(st[2]));
    }
}

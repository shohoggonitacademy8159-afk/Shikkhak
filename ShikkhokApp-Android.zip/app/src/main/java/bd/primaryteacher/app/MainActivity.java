package bd.primaryteacher.app;

import android.app.Activity;
import android.content.ClipData;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.provider.MediaStore;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.net.Uri;
import android.os.Bundle;
import android.util.Base64;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import android.print.PrintManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;

public class MainActivity extends Activity {

    private static final String ASSET_URL = "file:///android_asset/index.html";
    private static final String MARKER = "SHIKKHOK_APP";

    private WebView web;
    private SharedPreferences prefs;
    private File updFile;
    private JSONObject config;
    private boolean clearHistoryOnFinish = false;
    private WebView printView;
    private ValueCallback<Uri[]> fileCallback;
    private static final int PICK_FILE = 1001;
    private static final int SAVE_FILE = 1002;
    private static final int PICK_PDF = 1003;
    private static final int PICK_TREE = 1004;
    private static final int TAKE_PHOTO = 1005;
    private volatile boolean pageReady = false;
    private static final String BK_MAIN = "shikkhok-backup.json";
    private static final String BK_DAY = "shikkhok-backup-";
    private String pendingPdfKey;
    private File cameraFile;
    private File pendingSave;
    private final ExecutorService io = Executors.newSingleThreadExecutor();
    private final AtomicBoolean busy = new AtomicBoolean(false);
    private SmsSender sms;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(0xFF1E7F4F);

        prefs = getSharedPreferences("updates", MODE_PRIVATE);
        updFile = new File(new File(getFilesDir(), "www"), "index.html");
        config = readConfig();

        web = new WebView(this);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setTextZoom(100);
        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                if ("file".equals(uri.getScheme())) {
                    return false;
                }
                openExternal(uri);
                return true;
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                if (clearHistoryOnFinish) {
                    clearHistoryOnFinish = false;
                    view.clearHistory();
                }
                pageReady = true;
                // a photo taken while the app was closed in the background is handed over now
                if (prefs.getString("photoReadyKey", null) != null) notifyPhotoReady();
            }
        });
        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (fileCallback != null) {
                    fileCallback.onReceiveValue(null);
                }
                fileCallback = callback;
                try {
                    if (params.isCaptureEnabled()) {
                        // <input capture>: open the camera straight away
                        Intent cam = cameraIntent();
                        if (cam != null) {
                            startActivityForResult(cam, PICK_FILE);
                            return true;
                        }
                    }
                    Intent pick = params.createIntent();
                    if (params.getMode() == FileChooserParams.MODE_OPEN_MULTIPLE) {
                        pick.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
                    }
                    Intent chooser = Intent.createChooser(pick, "ছবি বেছে নিন");
                    Intent camera = cameraIntent();
                    if (camera != null) {
                        chooser.putExtra(Intent.EXTRA_INITIAL_INTENTS, new Intent[]{camera});
                    }
                    startActivityForResult(chooser, PICK_FILE);
                } catch (Exception e) {
                    fileCallback = null;
                    return false;
                }
                return true;
            }
        });
        sms = new SmsSender(this, new SmsSender.Listener() {
            @Override
            public void onResult(final String key, final boolean ok, final String code) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        web.evaluateJavascript("window.onSmsSent&&window.onSmsSent(" + JSONObject.quote(key) + "," + ok + "," + JSONObject.quote(code) + ")", null);
                    }
                });
            }
        });
        web.addJavascriptInterface(new Bridge(), "AppBridge");
        setContentView(web);
        loadApp();
    }

    /* ---------- which copy of the app to show ---------- */

    private int contentCode() {
        int c = prefs.getInt("contentCode", 0);
        return (c > BuildConfig.APP_CODE && updFile.exists()) ? c : BuildConfig.APP_CODE;
    }

    private String contentVersion() {
        if (contentCode() == BuildConfig.APP_CODE) {
            return BuildConfig.VERSION_NAME;
        }
        return prefs.getString("contentVersion", BuildConfig.VERSION_NAME);
    }

    private void loadApp() {
        if (contentCode() > BuildConfig.APP_CODE) {
            try {
                String html = new String(readAll(new FileInputStream(updFile)), StandardCharsets.UTF_8);
                if (html.contains(MARKER)) {
                    // Same base URL as the built-in copy, so saved data (localStorage) stays the same.
                    web.loadDataWithBaseURL(ASSET_URL, html, "text/html", "UTF-8", null);
                    return;
                }
            } catch (Exception ignored) {
            }
        }
        web.loadUrl(ASSET_URL);
    }

    /* ---------- update check ---------- */

    private JSONObject readConfig() {
        try {
            String txt = new String(readAll(getAssets().open("config.json")), StandardCharsets.UTF_8);
            JSONObject o = new JSONObject(txt);
            return o.has("updateBase") ? o : null;
        } catch (Exception e) {
            return null;
        }
    }

    private void doCheck(boolean manual) {
        if (config == null) {
            send(status("noconfig", manual));
            return;
        }
        send(status("checking", manual));
        try {
            String base = config.getString("updateBase");
            JSONObject v = new JSONObject(httpGet(base + "version.json?t=" + System.currentTimeMillis()));
            int code = v.getInt("code");
            int nativeCode = v.optInt("nativeCode", 0);
            String version = v.optString("version", "");
            String notes = v.optString("notes", "");

            boolean needApk = nativeCode > BuildConfig.NATIVE_CODE;
            boolean savedWeb = false;

            if (code > contentCode()) {
                String html = httpGet(base + "index.html?t=" + System.currentTimeMillis());
                if (html.length() < 10000 || !html.contains(MARKER)) {
                    throw new Exception("invalid update file");
                }
                File dir = updFile.getParentFile();
                if (dir != null && !dir.exists() && !dir.mkdirs()) {
                    throw new Exception("cannot create folder");
                }
                File tmp = new File(dir, "index.tmp");
                FileOutputStream out = new FileOutputStream(tmp);
                try {
                    out.write(html.getBytes(StandardCharsets.UTF_8));
                } finally {
                    out.close();
                }
                if (!tmp.renameTo(updFile)) {
                    throw new Exception("cannot save update");
                }
                prefs.edit().putInt("contentCode", code).putString("contentVersion", version).apply();
                savedWeb = true;
            }

            if (needApk) {
                // The new screens are saved too; the new APK is needed only for new phone features.
                JSONObject s = status("apk", manual);
                s.put("version", version);
                s.put("notes", notes);
                s.put("webSaved", savedWeb);
                s.put("url", "https://github.com/" + config.optString("repo", "")
                        + "/releases/latest/download/app-debug.apk");
                send(s);
                return;
            }
            if (savedWeb) {
                JSONObject s = status("web", manual);
                s.put("version", version);
                s.put("notes", notes);
                send(s);
                return;
            }

            send(status("uptodate", manual));
        } catch (Exception e) {
            send(status("error", manual));
        }
    }

    private JSONObject status(String state, boolean manual) {
        JSONObject o = new JSONObject();
        try {
            o.put("state", state);
            o.put("manual", manual);
        } catch (Exception ignored) {
        }
        return o;
    }

    private void send(JSONObject s) {
        final String js = "window.onUpdateStatus&&window.onUpdateStatus(" + JSONObject.quote(s.toString()) + ")";
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                web.evaluateJavascript(js, null);
            }
        });
    }

    private static String httpGet(String url) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        c.setConnectTimeout(15000);
        c.setReadTimeout(20000);
        c.setUseCaches(false);
        try {
            if (c.getResponseCode() != 200) {
                throw new Exception("HTTP " + c.getResponseCode());
            }
            return new String(readAll(c.getInputStream()), StandardCharsets.UTF_8);
        } finally {
            c.disconnect();
        }
    }

    private static byte[] readAll(InputStream in) throws Exception {
        try {
            ByteArrayOutputStream buf = new ByteArrayOutputStream();
            byte[] b = new byte[8192];
            int n;
            while ((n = in.read(b)) != -1) {
                buf.write(b, 0, n);
            }
            return buf.toByteArray();
        } finally {
            in.close();
        }
    }

    private void openExternal(Uri uri) {
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, uri));
        } catch (Exception ignored) {
        }
    }

    /* ---------- printing (certificates) ---------- */

    private void printHtml(String title, String html) {
        final String job = (title == null || title.trim().isEmpty()) ? "Certificate" : title.trim();
        final boolean landscape = html != null && html.contains("A4 landscape");
        final WebView pv = new WebView(this);
        pv.getSettings().setJavaScriptEnabled(false);
        pv.setWebViewClient(new WebViewClient() {
            private boolean done = false;

            @Override
            public void onPageFinished(WebView view, String url) {
                if (done) {
                    return;
                }
                done = true;
                // give bundled fonts (fonts/*.woff2) a moment to load before the print preview is laid out
                final WebView v = view;
                view.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        try {
                            PrintManager pm = (PrintManager) getSystemService(PRINT_SERVICE);
                            PrintDocumentAdapter adapter = v.createPrintDocumentAdapter(job);
                            PrintAttributes attrs = new PrintAttributes.Builder()
                                    .setMediaSize(landscape ? PrintAttributes.MediaSize.ISO_A4.asLandscape() : PrintAttributes.MediaSize.ISO_A4)
                                    .build();
                            pm.print(job, adapter, attrs);
                        } catch (Exception ignored) {
                        }
                    }
                }, 700);
            }
        });
        printView = pv; // keep a reference until printing is done
        pv.loadDataWithBaseURL(ASSET_URL, html, "text/html", "UTF-8", null);
    }

    /* ---------- functions the page can call ---------- */

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(requestCode, permissions, results);
        if (requestCode == SmsSender.PERM_REQUEST) {
            jsCall("onSmsPermission", String.valueOf(sms != null && sms.hasPermission()), "0");
        }
    }

    private class Bridge {
        /* ---- SMS from the phone's SIM ---- */
        @JavascriptInterface
        public String smsStatus() {
            return sms.status();
        }

        @JavascriptInterface
        public void smsRequestPermission() {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    sms.requestPermission();
                }
            });
        }

        @JavascriptInterface
        public void sendSms(final String key, final String phone, final String text, final int subId) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    sms.send(key, phone, text, subId);
                }
            });
        }

        @JavascriptInterface
        public String getInfo() {
            JSONObject o = new JSONObject();
            try {
                o.put("apk", BuildConfig.VERSION_NAME);
                o.put("content", contentVersion());
                o.put("configured", config != null);
            } catch (Exception ignored) {
            }
            return o.toString();
        }

        @JavascriptInterface
        public void checkUpdate(final boolean manual) {
            if (!busy.compareAndSet(false, true)) {
                return;
            }
            io.execute(new Runnable() {
                @Override
                public void run() {
                    try {
                        doCheck(manual);
                    } finally {
                        busy.set(false);
                    }
                }
            });
        }

        @JavascriptInterface
        public void applyUpdate() {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    clearHistoryOnFinish = true;
                    loadApp();
                }
            });
        }

        @JavascriptInterface
        public void print(final String title, final String html) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    printHtml(title, html);
                }
            });
        }

        @JavascriptInterface
        public void saveFile(final String name, final String mime, final String base64) {
            try {
                pendingSave = writeShared(name, base64);
            } catch (Exception e) {
                jsCallback("onFileSaved", false);
                return;
            }
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    try {
                        Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                        i.addCategory(Intent.CATEGORY_OPENABLE);
                        i.setType(mime);
                        i.putExtra(Intent.EXTRA_TITLE, pendingSave.getName());
                        startActivityForResult(i, SAVE_FILE);
                    } catch (Exception e) {
                        pendingSave = null;
                        jsCallback("onFileSaved", false);
                    }
                }
            });
        }

        @JavascriptInterface
        public void shareFile(final String name, final String mime, final String base64) {
            final File f;
            try {
                f = writeShared(name, base64);
            } catch (Exception e) {
                return;
            }
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    try {
                        Uri u = CacheFileProvider.uriFor(f);
                        Intent send = new Intent(Intent.ACTION_SEND);
                        send.setType(mime);
                        send.putExtra(Intent.EXTRA_STREAM, u);
                        send.setClipData(ClipData.newRawUri("", u));
                        send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                        startActivity(Intent.createChooser(send, "শেয়ার করুন"));
                    } catch (Exception ignored) {
                    }
                }
            });
        }

        @JavascriptInterface
        public void takePhoto(final String key) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    startCamera(key);
                }
            });
        }

        /** The last photo from takePhoto as {key, data:"data:image/jpeg;base64,..."}, handed over once. */
        @JavascriptInterface
        public String photoResult() {
            String key = prefs.getString("photoReadyKey", null);
            if (key == null) return "";
            prefs.edit().remove("photoReadyKey").apply();
            try {
                File f = new File(CacheFileProvider.dir(MainActivity.this), "photo_result.jpg");
                if (!f.exists()) return "";
                String b64 = Base64.encodeToString(readAll(new FileInputStream(f)), Base64.NO_WRAP);
                f.delete();
                JSONObject o = new JSONObject();
                o.put("key", key);
                o.put("data", "data:image/jpeg;base64," + b64);
                return o.toString();
            } catch (Exception e) {
                return "";
            }
        }

        @JavascriptInterface
        public void mirror(final String json) {
            io.execute(new Runnable() {
                @Override
                public void run() {
                    try {
                        writeMirror(json);
                    } catch (Exception ignored) {
                    }
                }
            });
        }

        @JavascriptInterface
        public String readMirror() {
            try {
                File f = new File(getFilesDir(), "mirror.json");
                return f.exists() ? new String(readAll(new FileInputStream(f)), StandardCharsets.UTF_8) : "";
            } catch (Exception e) {
                return "";
            }
        }

        @JavascriptInterface
        public String backupInfo() {
            try {
                JSONObject o = new JSONObject();
                Uri t = backupTree();
                o.put("folder", t == null ? "" : treeLabel(t));
                o.put("last", String.valueOf(prefs.getLong("bkLast", 0)));
                return o.toString();
            } catch (Exception e) {
                return "{}";
            }
        }

        @JavascriptInterface
        public void chooseBackupFolder() {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    try {
                        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
                        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                                | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
                        startActivityForResult(i, PICK_TREE);
                    } catch (Exception e) {
                        jsCall("onBackupFolder", "false", "\"\"");
                    }
                }
            });
        }

        @JavascriptInterface
        public void writeBackup(final String json) {
            final Uri tree = backupTree();
            if (tree == null) {
                return;
            }
            io.execute(new Runnable() {
                @Override
                public void run() {
                    boolean ok = false;
                    try {
                        byte[] data = json.getBytes(StandardCharsets.UTF_8);
                        java.util.Map<String, String> kids = listTree(tree);
                        writeDoc(tree, kids, BK_MAIN, data);
                        String day = new java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US).format(new java.util.Date());
                        writeDoc(tree, kids, BK_DAY + day + ".json", data);
                        // keep the 10 newest daily copies
                        java.util.List<String> days = new java.util.ArrayList<String>();
                        for (String n : kids.keySet()) {
                            if (n.startsWith(BK_DAY) && n.endsWith(".json")) days.add(n);
                        }
                        if (!days.contains(BK_DAY + day + ".json")) days.add(BK_DAY + day + ".json");
                        java.util.Collections.sort(days);
                        for (int i = 0; i < days.size() - 10; i++) {
                            String id = kids.get(days.get(i));
                            if (id != null) {
                                android.provider.DocumentsContract.deleteDocument(getContentResolver(),
                                        android.provider.DocumentsContract.buildDocumentUriUsingTree(tree, id));
                            }
                        }
                        prefs.edit().putLong("bkLast", System.currentTimeMillis()).apply();
                        ok = true;
                    } catch (Exception ignored) {
                    }
                    jsCall("onBackupWritten", String.valueOf(ok), String.valueOf(System.currentTimeMillis()));
                }
            });
        }

        @JavascriptInterface
        public void readBackup() {
            final Uri tree = backupTree();
            io.execute(new Runnable() {
                @Override
                public void run() {
                    String text = "";
                    try {
                        if (tree != null) {
                            java.util.Map<String, String> kids = listTree(tree);
                            String pick = kids.containsKey(BK_MAIN) ? BK_MAIN : null;
                            if (pick == null) {
                                for (String n : kids.keySet()) {
                                    if (n.startsWith(BK_DAY) && n.endsWith(".json") && (pick == null || n.compareTo(pick) > 0)) pick = n;
                                }
                            }
                            if (pick != null) {
                                Uri doc = android.provider.DocumentsContract.buildDocumentUriUsingTree(tree, kids.get(pick));
                                text = new String(readAll(getContentResolver().openInputStream(doc)), StandardCharsets.UTF_8);
                            }
                        }
                    } catch (Exception ignored) {
                    }
                    jsCall("onBackupRead", JSONObject.quote(text), "0");
                }
            });
        }

        @JavascriptInterface
        public void pickPdf(final String key) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    try {
                        pendingPdfKey = key;
                        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                        i.addCategory(Intent.CATEGORY_OPENABLE);
                        i.setType("application/pdf");
                        startActivityForResult(i, PICK_PDF);
                    } catch (Exception e) {
                        pendingPdfKey = null;
                    }
                }
            });
        }

        @JavascriptInterface
        public String listPdfs() {
            JSONObject m = pdfMap(), out = new JSONObject();
            try {
                java.util.Iterator<String> it = m.keys();
                while (it.hasNext()) {
                    String k = it.next();
                    out.put(k, m.getJSONObject(k).optString("name", "PDF"));
                }
            } catch (Exception ignored) {
            }
            return out.toString();
        }

        @JavascriptInterface
        public void removePdf(String key) {
            JSONObject m = pdfMap();
            m.remove(key);
            prefs.edit().putString("pdfs", m.toString()).apply();
        }

        @JavascriptInterface
        public String openPdf(final String key) {
            JSONObject e = pdfMap().optJSONObject(key);
            if (e == null) {
                return "missing";
            }
            final Uri u = Uri.parse(e.optString("uri"));
            try {
                getContentResolver().openInputStream(u).close();
            } catch (Exception ex) {
                return "gone";
            }
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    try {
                        Intent v = new Intent(Intent.ACTION_VIEW);
                        v.setDataAndType(u, "application/pdf");
                        v.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                        startActivity(Intent.createChooser(v, "PDF খুলুন"));
                    } catch (Exception ignored) {
                    }
                }
            });
            return "ok";
        }

        @JavascriptInterface
        public void openUrl(final String url) {
            if (url == null || !url.startsWith("https://github.com/")) {
                return;
            }
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    openExternal(Uri.parse(url));
                }
            });
        }
    }

    @Override
    @SuppressWarnings("deprecation")
    public void onBackPressed() {
        if (web.canGoBack()) {
            web.goBack();
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == SAVE_FILE) {
            finishSave(resultCode == RESULT_OK && data != null ? data.getData() : null);
            return;
        }
        if (requestCode == PICK_PDF) {
            finishPdfPick(resultCode == RESULT_OK && data != null ? data.getData() : null);
            return;
        }
        if (requestCode == TAKE_PHOTO) {
            finishPhoto(resultCode, data);
            return;
        }
        if (requestCode == PICK_TREE) {
            finishTreePick(resultCode == RESULT_OK && data != null ? data.getData() : null);
            return;
        }
        if (requestCode != PICK_FILE || fileCallback == null) {
            return;
        }
        Uri[] result = null;
        if (resultCode == RESULT_OK) {
            if (data != null && data.getClipData() != null && data.getClipData().getItemCount() > 0 && data.getData() == null) {
                ClipData cd = data.getClipData();
                result = new Uri[cd.getItemCount()];
                for (int i = 0; i < cd.getItemCount(); i++) {
                    result[i] = cd.getItemAt(i).getUri();
                }
            } else {
                result = WebChromeClient.FileChooserParams.parseResult(resultCode, data);
            }
            if ((result == null || result.length == 0) && cameraFile != null && cameraFile.length() > 0) {
                // content:// through our provider — the page may not read file:// paths on newer Android
                result = new Uri[]{CacheFileProvider.uriFor(cameraFile)};
            }
            // A camera app without an output file returns a small picture in the extras.
            if ((result == null || result.length == 0) && data != null && data.getExtras() != null) {
                Object extra = data.getExtras().get("data");
                if (extra instanceof Bitmap) {
                    try {
                        File f = new File(CacheFileProvider.dir(this), "camera_" + System.currentTimeMillis() + ".jpg");
                        FileOutputStream out = new FileOutputStream(f);
                        try {
                            ((Bitmap) extra).compress(Bitmap.CompressFormat.JPEG, 90, out);
                        } finally {
                            out.close();
                        }
                        result = new Uri[]{CacheFileProvider.uriFor(f)};
                    } catch (Exception ignored) {
                    }
                }
            }
        }
        fileCallback.onReceiveValue(result);
        fileCallback = null;
        cameraFile = null;
    }

    /* ---------- camera ----------
     * The camera writes a full-size photo straight into our cache through the app's own provider (no storage
     * permission needed). The file name is kept in settings, so the photo is not lost even if Android closes the
     * app while the camera is open; the page collects it with AppBridge.photoResult(). */

    private Intent cameraIntent() {
        Intent camera = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        java.util.List<android.content.pm.ResolveInfo> apps = getPackageManager().queryIntentActivities(camera, 0);
        if (apps == null || apps.isEmpty()) {
            return null;
        }
        cameraFile = new File(CacheFileProvider.dir(this), "camera_" + System.currentTimeMillis() + ".jpg");
        prefs.edit().putString("camFile", cameraFile.getAbsolutePath()).apply();
        Uri out = CacheFileProvider.uriFor(cameraFile);
        camera.putExtra(MediaStore.EXTRA_OUTPUT, out);
        camera.setClipData(ClipData.newRawUri("", out));
        camera.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
        // When the camera is started through a chooser the flags are not always passed on, so grant every camera app.
        for (android.content.pm.ResolveInfo ri : apps) {
            grantUriPermission(ri.activityInfo.packageName, out, Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
        }
        return camera;
    }

    private void startCamera(String key) {
        try {
            Intent cam = cameraIntent();
            if (cam == null) {
                photoFailed(key, "nocamera");
                return;
            }
            prefs.edit().putString("camKey", key).apply();
            startActivityForResult(cam, TAKE_PHOTO);
        } catch (Exception e) {
            photoFailed(key, "error");
        }
    }

    private void photoFailed(String key, String why) {
        jsCall("onPhotoFailed", JSONObject.quote(key == null ? "" : key), JSONObject.quote(why));
    }

    private void finishPhoto(final int resultCode, final Intent data) {
        final String key = prefs.getString("camKey", null);
        String path = prefs.getString("camFile", null);
        prefs.edit().remove("camKey").remove("camFile").apply();
        final File shot = path == null ? null : new File(path);
        if (resultCode != RESULT_OK) {
            if (shot != null) shot.delete();
            photoFailed(key, "cancel");
            return;
        }
        final Object extra = (data != null && data.getExtras() != null) ? data.getExtras().get("data") : null;
        final Bitmap thumb = extra instanceof Bitmap ? (Bitmap) extra : null;
        io.execute(new Runnable() {
            @Override
            public void run() {
                try {
                    Bitmap bmp = null;
                    if (shot != null && shot.length() > 0) {
                        bmp = decodeScaled(shot.getAbsolutePath(), 2400);
                    }
                    if (bmp == null) bmp = thumb;
                    if (bmp == null) {
                        photoFailed(key, "empty");
                        return;
                    }
                    File outFile = new File(CacheFileProvider.dir(MainActivity.this), "photo_result.jpg");
                    FileOutputStream out = new FileOutputStream(outFile);
                    try {
                        bmp.compress(Bitmap.CompressFormat.JPEG, 88, out);
                    } finally {
                        out.close();
                    }
                    if (shot != null) shot.delete();
                    prefs.edit().putString("photoReadyKey", key == null ? "" : key).apply();
                    if (pageReady) notifyPhotoReady();
                } catch (Throwable t) {
                    photoFailed(key, "error");
                }
            }
        });
    }

    private void notifyPhotoReady() {
        String key = prefs.getString("photoReadyKey", "");
        jsCall("onPhotoReady", JSONObject.quote(key), "0");
    }

    /** Decode a camera JPEG no larger than max px on its long side, turned upright from its EXIF orientation. */
    private static Bitmap decodeScaled(String path, int max) throws Exception {
        android.graphics.BitmapFactory.Options o = new android.graphics.BitmapFactory.Options();
        o.inJustDecodeBounds = true;
        android.graphics.BitmapFactory.decodeFile(path, o);
        int sample = 1;
        while (Math.max(o.outWidth, o.outHeight) / (sample * 2) >= max) sample *= 2;
        android.graphics.BitmapFactory.Options d = new android.graphics.BitmapFactory.Options();
        d.inSampleSize = sample;
        Bitmap b = android.graphics.BitmapFactory.decodeFile(path, d);
        if (b == null) return null;
        float k = Math.min(1f, (float) max / Math.max(b.getWidth(), b.getHeight()));
        int deg = 0;
        try {
            int or = new android.media.ExifInterface(path).getAttributeInt(android.media.ExifInterface.TAG_ORIENTATION, android.media.ExifInterface.ORIENTATION_NORMAL);
            if (or == android.media.ExifInterface.ORIENTATION_ROTATE_90) deg = 90;
            else if (or == android.media.ExifInterface.ORIENTATION_ROTATE_180) deg = 180;
            else if (or == android.media.ExifInterface.ORIENTATION_ROTATE_270) deg = 270;
        } catch (Exception ignored) {
        }
        if (k < 1f || deg != 0) {
            android.graphics.Matrix m = new android.graphics.Matrix();
            m.postScale(k, k);
            m.postRotate(deg);
            Bitmap r = Bitmap.createBitmap(b, 0, 0, b.getWidth(), b.getHeight(), m, true);
            if (r != b) b.recycle();
            b = r;
        }
        return b;
    }

    /* ---------- automatic backup ----------
     * 1) Every change is mirrored to a file inside the app (also picked up by Android's own Google backup).
     * 2) If the teacher picks a folder once, the full backup is written there automatically; that folder
     *    survives uninstalling the app, and after reinstalling, picking it again brings everything back. */

    private Uri backupTree() {
        String t = prefs.getString("bkTree", null);
        return t == null ? null : Uri.parse(t);
    }

    private String treeLabel(Uri tree) {
        try {
            String id = android.provider.DocumentsContract.getTreeDocumentId(tree);
            int i = id.indexOf(':');
            String path = i >= 0 ? id.substring(i + 1) : id;
            return path.isEmpty() ? "ফোনের স্টোরেজ" : path;
        } catch (Exception e) {
            return "বেছে নেওয়া ফোল্ডার";
        }
    }

    private void finishTreePick(Uri tree) {
        if (tree == null) {
            jsCall("onBackupFolder", "false", "\"\"");
            return;
        }
        try {
            getContentResolver().takePersistableUriPermission(tree, Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
        } catch (Exception ignored) {
        }
        prefs.edit().putString("bkTree", tree.toString()).apply();
        jsCall("onBackupFolder", "true", JSONObject.quote(treeLabel(tree)));
    }

    private void jsCall(final String fn, final String a, final String b) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                web.evaluateJavascript("window." + fn + "&&window." + fn + "(" + a + "," + b + ")", null);
            }
        });
    }

    /** name -> document id of the files directly inside the backup folder */
    private java.util.Map<String, String> listTree(Uri tree) {
        java.util.Map<String, String> out = new java.util.HashMap<String, String>();
        String parent = android.provider.DocumentsContract.getTreeDocumentId(tree);
        Uri kids = android.provider.DocumentsContract.buildChildDocumentsUriUsingTree(tree, parent);
        android.database.Cursor c = getContentResolver().query(kids, new String[]{
                android.provider.DocumentsContract.Document.COLUMN_DOCUMENT_ID,
                android.provider.DocumentsContract.Document.COLUMN_DISPLAY_NAME}, null, null, null);
        if (c != null) {
            try {
                while (c.moveToNext()) {
                    out.put(c.getString(1), c.getString(0));
                }
            } finally {
                c.close();
            }
        }
        return out;
    }

    private void writeDoc(Uri tree, java.util.Map<String, String> kids, String name, byte[] data) throws Exception {
        Uri doc;
        if (kids.containsKey(name)) {
            doc = android.provider.DocumentsContract.buildDocumentUriUsingTree(tree, kids.get(name));
        } else {
            Uri parent = android.provider.DocumentsContract.buildDocumentUriUsingTree(tree, android.provider.DocumentsContract.getTreeDocumentId(tree));
            doc = android.provider.DocumentsContract.createDocument(getContentResolver(), parent, "application/json", name);
            if (doc == null) throw new Exception("create failed");
        }
        java.io.OutputStream out = getContentResolver().openOutputStream(doc, "wt");
        try {
            out.write(data);
        } finally {
            out.close();
        }
    }

    private void writeMirror(String json) throws Exception {
        File dir = getFilesDir();
        File tmp = new File(dir, "mirror.tmp"), dst = new File(dir, "mirror.json");
        FileOutputStream out = new FileOutputStream(tmp);
        try {
            out.write(json.getBytes(StandardCharsets.UTF_8));
            out.getFD().sync();
        } finally {
            out.close();
        }
        if (!tmp.renameTo(dst)) {
            dst.delete();
            tmp.renameTo(dst);
        }
    }

    /* ---------- textbook PDFs kept on the phone: we remember a link to the user's file, not a copy ---------- */

    private JSONObject pdfMap() {
        try {
            return new JSONObject(prefs.getString("pdfs", "{}"));
        } catch (Exception e) {
            return new JSONObject();
        }
    }

    private String displayName(Uri u) {
        String name = null;
        try {
            android.database.Cursor c = getContentResolver().query(u, new String[]{android.provider.OpenableColumns.DISPLAY_NAME}, null, null, null);
            if (c != null) {
                try {
                    if (c.moveToFirst()) name = c.getString(0);
                } finally {
                    c.close();
                }
            }
        } catch (Exception ignored) {
        }
        return name == null ? "PDF" : name;
    }

    private void finishPdfPick(Uri u) {
        final String key = pendingPdfKey;
        pendingPdfKey = null;
        if (u == null || key == null) {
            return;
        }
        try {
            getContentResolver().takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION);
        } catch (Exception ignored) {
        }
        try {
            JSONObject m = pdfMap();
            JSONObject e = new JSONObject();
            e.put("uri", u.toString());
            e.put("name", displayName(u));
            m.put(key, e);
            prefs.edit().putString("pdfs", m.toString()).apply();
            final String js = "window.onPdfPicked&&window.onPdfPicked(" + JSONObject.quote(key) + "," + JSONObject.quote(e.getString("name")) + ")";
            web.evaluateJavascript(js, null);
        } catch (Exception ignored) {
        }
    }

    /* ---------- saving and sharing files made in the page (e.g. PDF) ---------- */

    private File writeShared(String name, String base64) throws Exception {
        String safe = name == null ? "file" : name.replaceAll("[\\\\/:*?\"<>|]", "_");
        File f = new File(CacheFileProvider.dir(this), safe);
        FileOutputStream out = new FileOutputStream(f);
        try {
            out.write(Base64.decode(base64, Base64.DEFAULT));
        } finally {
            out.close();
        }
        return f;
    }

    private void jsCallback(final String fn, final boolean ok) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                web.evaluateJavascript("window." + fn + "&&window." + fn + "(" + ok + ")", null);
            }
        });
    }

    private void finishSave(final Uri target) {
        final File src = pendingSave;
        pendingSave = null;
        if (target == null || src == null) {
            jsCallback("onFileSaved", false);
            return;
        }
        io.execute(new Runnable() {
            @Override
            public void run() {
                boolean ok = false;
                try {
                    java.io.OutputStream out = getContentResolver().openOutputStream(target);
                    InputStream in = new FileInputStream(src);
                    try {
                        byte[] buf = new byte[65536];
                        int n;
                        while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
                        ok = true;
                    } finally {
                        in.close();
                        if (out != null) out.close();
                    }
                } catch (Exception ignored) {
                }
                jsCallback("onFileSaved", ok);
            }
        });
    }

    @Override
    protected void onDestroy() {
        io.shutdownNow();
        if (sms != null) sms.release();
        super.onDestroy();
    }
}
